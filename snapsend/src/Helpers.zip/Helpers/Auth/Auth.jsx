
const Auth = {
    getAuth: () => {
        const auth = localStorage.getItem('servalley-auth');
        if (!auth) {
            return null;
        }
        return JSON.parse(auth);
    },
    setAuth: (auth) => {
        localStorage.setItem('servalley-auth', JSON.stringify(auth));
    },
    removeAuth: () => {
        localStorage.removeItem('servalley-auth');
    },

    // checkAuth: (data) => {
    //     // eslint-disable-next-line
    //     if (data.response_code == 401) {
    //         Auth.logout()
    //         window.location.reload()
    //     }
    // },
    // getCurrentUser: () => {
    //     const currentUser = localStorage.getItem('currentUser');
    //     if (!currentUser) {
    //         return null;
    //     }
    //     return JSON.parse(currentUser);
    // },
}
// console.log(AuthHelp)
export default { ...Auth };