import validator from "validator";

export default class Validation {
  static validate(type, value) {
    let isValidate = null;
    switch (type) {
        case "username":
            isValidate = validator.isEmpty(value) || value.length < 3 ? false : true;
        break;

        case "email":
            isValidate = validator.isEmail(value) ? true : false;
        break;

        case "password":
            isValidate = value.length >= 4 && value.length <= 50 ?  true : false;
        break;

        case "mobile":
            isValidate = value.length < 10 || value.length > 10 ?  false : true;
        break;

        case "country_code":
            isValidate = value.length == null || value == "" ?  false : true;
        break;

      default:
        break;

    }
    return isValidate;
  }
}