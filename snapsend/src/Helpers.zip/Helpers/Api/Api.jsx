const Api = {
    SEND_OTP : "api/sendotp",
    REGISTER : "api/register",
    LOGIN : "api/login",
    VERIFY_OTP : "api/verify_otp",
    FORGOT_PASS : "api/forgot",
    CHANGE_PASSWORD : "api/change_password",
    CATEGORIES: "api/categories",
    SUB_CATEGORY : "api/sub_categories",
    REGISTER_PROVIDER : "api/registerprovider",
    PROVIDER_SERVICES : "api/providerservices",
    UPDATE_PROVIDER : "api/updateprovider",
    DEMO_UPLOAD : "api/demoupload",
    CERTIFICATE_UPLOAD : "api/certificateupload",
    GET_USER : "api/getuser",
    PROVIDER_LIST : "api/providerslist",
    PROVIDER_REVIEW : "api/providerreviews",
    SET_FAVOURITE : "api/setfavorite",
    CHANGE_OLD_PASSWORD : "api/changed_password_profile",
    UPDATE_PROFILE : "api/updateuserprofile",
    PROFILE_IMAGE : "api/profileimageupload",
    USER_CERTIFICATE_UPLOAD : "api/usercertificateupload",
    REQUEST_QUOTE : "api/request_quote",
    DELETE_SERVICE : "api/deleteproviders",
    PROJECTS : "api/projects",
    PROJECT_DETAILS : "api/project_details",


    HOME_API : "api/home",
}

export default Api;